
// Demo configuration

#define TEST_PRINTCONFIGURATION			1	

/////////// EOF