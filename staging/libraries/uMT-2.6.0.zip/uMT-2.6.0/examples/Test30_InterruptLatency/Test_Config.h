
// Demo configuration

#define TEST_INT_LATENCY_01			1	

/////////// EOF