
// Demo configuration

#define TEST_STACK_UTILIZATION		1	

/////////// EOF