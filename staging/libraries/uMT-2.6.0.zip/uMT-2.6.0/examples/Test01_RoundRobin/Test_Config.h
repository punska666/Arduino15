
// Demo configuration

#define TEST_ROUNDROBIN			1		// Test self Yield()

/////////// EOF