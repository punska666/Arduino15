
// Demo configuration

#define TEST_TIMERS2			1 

/////////// EOF