
// Demo configuration

#define TEST_EVENTS_TIMEOUT			1 

/////////// EOF