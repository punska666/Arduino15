
// Demo configuration

#define TEST_EVENTS_TIMERS			1 

/////////// EOF